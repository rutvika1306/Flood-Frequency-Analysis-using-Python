# -*- coding: utf-8 -*-
"""
Created on Sat Apr 12 19:09:48 2025

@author: rutvi
"""

import pandas as pd
import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit



#file loading
df = pd.read_excel("C:/Users/rutvi/Downloads/Data (1)_b8a0b784-4a74-47dd-93d6-7e6db36e9951.xlsx", sheet_name="p1")

#column renaming
df.columns = ['Year', '5 min', '10 min', '15 min', '30 min', '1hr', '2 hr', '6 hr', '12 hr', '24 hr']
df = df[1:].reset_index(drop=True)

#converting data to numeric
df = df.apply(pd.to_numeric)


def fit(data_series):
    data = data_series.dropna().values

    #Log-Normal Fit
    log_data = np.log(data)
    mu_ln = np.mean(log_data)    #mean
    sigma_ln = np.std(log_data, ddof=1)          #standard deviation
    ks_stat_ln, ks_pval_ln = stats.kstest(log_data, 'norm', args=(mu_ln, sigma_ln))

    #Gumbel Fit
    loc_g, scale_g = stats.gumbel_r.fit(data)  #alpha and beta
    ks_stat_g, ks_pval_g = stats.kstest(data, 'gumbel_r', args=(loc_g, scale_g))

    return {
        'LogNormal': {'mu': mu_ln, 'sigma': sigma_ln, 'p_value': ks_pval_ln},
        'Gumbel': {'loc': loc_g, 'scale': scale_g, 'p_value': ks_pval_g}
    }


results = {}
for duration in df.columns[1:]:
    results[duration] = fit(df[duration])

#print the comparison
for duration, res in results.items():
    print(f"\n--- {duration} ---")
    print("Log-Normal KS p-value:", res['LogNormal']['p_value'])
    print("Gumbel KS p-value:", res['Gumbel']['p_value'])
    best = "Log-Normal" if res['LogNormal']['p_value'] > res['Gumbel']['p_value'] else "Gumbel"
    print("Best fit:", best)
    
    
def estimate_ln(mu, sigma, T):
    z = stats.norm.ppf(1 - 1/T)
    return np.exp(mu + z * sigma)


def estimate_gumbel(loc, scale, T):
    yT = -np.log(-np.log(1 - 1/T))   #reduced variate yT = -ln(-ln(1 - 1/T))
    return loc + scale * yT



#durations in hours
duration_labels = ['5 min', '10 min', '15 min', '30 min', '1hr', '2 hr', '6 hr', '12 hr', '24 hr']
durations_hr = [5/60, 10/60, 15/60, 0.5, 1, 2, 6, 12, 24]  # hours
return_periods = [2, 5, 10, 25, 50]

#store intensities
idf_data = {T: [] for T in return_periods}

#calculating intensity for each duration and return period
for duration_label, duration_hr in zip(duration_labels, durations_hr):
    res = results[duration_label]
    if res['LogNormal']['p_value'] > res['Gumbel']['p_value']:
        mu = res['LogNormal']['mu']
        sigma = res['LogNormal']['sigma']
        for T in return_periods:
            rainfall = estimate_ln(mu, sigma, T)
            intensity = rainfall / duration_hr
            idf_data[T].append(intensity)
    else:
        loc = res['Gumbel']['loc']
        scale = res['Gumbel']['scale']
        for T in return_periods:
            rainfall = estimate_gumbel(loc, scale, T)
            intensity = rainfall / duration_hr
            idf_data[T].append(intensity)

#plotting
plt.figure(figsize=(10, 6))
for T in return_periods:
    plt.plot(durations_hr, idf_data[T], marker='o', label=f"{T}-year")

plt.xscale('log')
#plt.yscale('log')
plt.xlabel("Duration (hr)")
plt.ylabel("Intensity (mm/hr)")
plt.title("Intensity-Duration-Frequency (IDF) Curves")
plt.grid(True, which="both")
plt.legend(title="Return Period")
plt.tight_layout()
plt.show()



#empirical IDF function
def idf_empirical(DT, K, x, a, n):
    D, T = DT
    return K * T**x / (D + a)**n

idf_data_cm = {T: [i/10 for i in idf_data[T]] for T in return_periods} 


#flatten data for curve fitting
D_vals = []  # durations in minutes
T_vals = []  # return periods
i_vals = []  # corresponding intensities

for i, D in enumerate(durations_hr):  #D in hours
    D_min = D * 60
    for T in return_periods:
        D_vals.append(D_min)
        T_vals.append(T)
        i_vals.append(idf_data_cm[T][i])  #intensity value

#fitting the model
popt, pcov = curve_fit(idf_empirical, (np.array(D_vals), np.array(T_vals)), i_vals,bounds=([0, 0, 0, 0], [100, 1, 20, 3]))
K_fit, x_fit, a_fit, n_fit = popt

print("Fitted parameters:")
print(f"\nK = {K_fit:.4f}, x = {x_fit:.4f}, a = {a_fit:.4f}, n = {n_fit:.4f}")



D_range = np.linspace(min(D_vals), max(D_vals), 100)  #duration in minutes


plt.figure(figsize=(10, 6))

for T in return_periods:
    I_fit = [idf_empirical((D, T), K_fit, x_fit, a_fit, n_fit) for D in D_range]
    plt.plot(D_range, I_fit, label=f"T = {T} years")
    
plt.title("Fitted IDF Curves")
plt.xlabel("Duration (minutes)")
plt.ylabel("Rainfall Intensity (mm/hr)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()



